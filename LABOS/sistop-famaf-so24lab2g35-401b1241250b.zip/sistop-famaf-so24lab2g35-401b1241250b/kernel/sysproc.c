#include "types.h"
#include "riscv.h"
#include "defs.h"
#include "param.h"
#include "memlayout.h"
#include "spinlock.h"
#include "proc.h"

uint64
sys_exit(void)
{
  int n;
  argint(0, &n);
  exit(n);
  return 0;  // not reached
}

uint64
sys_getpid(void)
{
  return myproc()->pid;
}

uint64
sys_fork(void)
{
  return fork();
}

uint64
sys_wait(void)
{
  uint64 p;
  argaddr(0, &p);
  return wait(p);
}

uint64
sys_sbrk(void)
{
  uint64 addr;
  int n;

  argint(0, &n);
  addr = myproc()->sz;
  if(growproc(n) < 0)
    return -1;
  return addr;
}

uint64
sys_sleep(void)
{
  int n;
  uint ticks0;

  argint(0, &n);
  acquire(&tickslock);
  ticks0 = ticks;
  while(ticks - ticks0 < n){
    if(killed(myproc())){
      release(&tickslock);
      return -1;
    }
    sleep(&ticks, &tickslock);
  }
  release(&tickslock);
  return 0;
}

uint64
sys_kill(void)
{
  int pid;

  argint(0, &pid);
  return kill(pid);
}

// return how many clock tick interrupts have occurred
// since start.
uint64
sys_uptime(void)
{
  uint xticks;

  acquire(&tickslock);
  xticks = ticks;
  release(&tickslock);
  return xticks;
}

//SEMAFORUWUS
#define MAX_SEM 512

struct sem {
    int value; // Valor del semáforo
    struct spinlock lock; // Spinlock para el semáforo
};

struct sem sem_count[MAX_SEM];

uint64 sys_sem_open(void) {
    int sem_id, init_value;
    //recibo los argumentos del semaforo
    argint(0, &sem_id); //identifico el semaforo con un ID
    argint(1, &init_value); //asigna valor inicial al semaforo


    //Validaciones
    if (sem_id < 0 || init_value < 0){
      return -1;
    }

    if (sem_id < 0 || sem_id >= MAX_SEM){
      return -1; // checkea que el ID este dentro del rango permitido
    }

    initlock(&sem_count[sem_id].lock, "semaphore"); // Inicializar spinlock
    acquire(&sem_count[sem_id].lock);  //Spinlock para que ningun otro proceso acceda al mismo semaforo a la vez
    sem_count[sem_id].value = init_value; // Inicializar semáforo
    release(&sem_count[sem_id].lock);

    return 0; //para el caso de ERROR devuelve -1

}



uint64 sys_sem_close(void){
  int sem_id;
  argint(0, &sem_id);

    if (sem_id < 0 || sem_id >= MAX_SEM){
      return -1;
    }

    acquire(&sem_count[sem_id].lock);
    sem_count[sem_id].value = -1; // CERRAR SEMAFORO
    release(&sem_count[sem_id].lock);
  return 0;
}



uint64 sys_sem_up(void) {
    int sem_id;
    argint(0, &sem_id);

    if (sem_id < 0 || sem_id >= MAX_SEM){
      return -1;
    }

    acquire(&sem_count[sem_id].lock);
    if (sem_count[sem_id].value == 0){
      wakeup(&sem_count[sem_id]); // Despertar a los procesos en espera
    }
    
    sem_count[sem_id].value++;  // Incrementar valor
    release(&sem_count[sem_id].lock); // Liberar spinlock

    return 0;
}

uint64 sys_sem_down(void) {
  int sem_id;
  argint(0, &sem_id);

  if (sem_id < 0 || sem_id >= MAX_SEM){
  return -1;
  }

  //ZONA CRITICA
  acquire(&sem_count[sem_id].lock);
  while (sem_count[sem_id].value == 0) {
    sleep(&sem_count[sem_id], &sem_count[sem_id].lock); // Bloquear proceso
  }

  sem_count[sem_id].value--;  // Decremento el valor del sem
  release(&sem_count[sem_id].lock);

  return 0;
}
 

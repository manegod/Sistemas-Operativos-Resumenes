#include "kernel/types.h"
#include "kernel/stat.h"
#include "user.h"

int main(int argc, char **argv){
    if (argc != 2){
        printf("ERROR: se acepta un solo argumento\n");
        return 0;
    }   

    int rondas = atoi(argv[1]);

    if (rondas < 1){
        printf("ERROR: el numero de rondas debe ser mayor a 0\n");
        return 1;
    }

    int ping = sem_open(0,1);
    int pong = sem_open(1,0);
    if (ping < 0 || pong < 0){
        printf("ERROR: problema con los semaforos\n");
        return 1;
    }

    int pid = fork();
    if (pid < 0){ // error
        printf("ERROR: problema con el fork\n");
        exit(1);
    } else if (pid == 0){ // hijo
        for (int i = 0; i < rondas; i++){
            pong = sem_down(1);
            printf("\tpong\n");
            ping = sem_up(0);
        }
    } else if (pid > 0){ // padre
        for (int i = 0; i < rondas; i++){
            ping = sem_down(0);
            printf("ping\n");
            pong = sem_up(1);
        }
        wait(0);
    }
    sem_close(0);
    sem_close(1);
    return 0;
}
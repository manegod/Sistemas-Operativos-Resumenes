# wolOS g35 - lab1
## *Autores:* 
- Francisco Asis
- Lautaro Gaston Peralta
- Maria Luz Varas
- Santiago Ezequiel Sanchez
## Breve informe sobre el proyecto
#### Archivos contenidos: 

* builtin.h - builtin.c
    
        Se encarga de verificar y ejecutar los comandos internos.

* parsing.h - parsing.c

        Contiene la función parse_pipeline la cual parsea los pipelines de los comandos y crea una estructura correspondiente de datos.
* command.h - command.c

        Se encuentran definiciones y funciones básicas relacionadas a los comandos simples y pipelines.
* strextra.h - strextra.c

        Incorpora las funciones strmerge y str_merge_new, ambas tienen como objetivo concatenar dos cadenas. Definimos str_merge_new para asegurarnos que la memoria sea ajustada y gestionada correctamente.
* execute.h - execute.c

        Abarca las funciones para ejecutar pipelines, identificar comandos internos y redireccionar apropiadamente.

## Conclusiones:
        Buen trabajo en grupo sobre un tema no tan conocido. Nos ayuda a entendernos mejor en cuestion de rendimiento y organizacion. Creemos que simula bastante bien el proceso de llegar sin muchos conocimientos ante una problematica que se nos pueda prensentar ejerciendo, de la cual poco a poco y con ayuda de nuestros compañeros podemos aprender y adaptarnos.     
#
#

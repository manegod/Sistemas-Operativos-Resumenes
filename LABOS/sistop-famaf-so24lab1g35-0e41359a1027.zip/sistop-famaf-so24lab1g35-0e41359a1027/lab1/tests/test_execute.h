#ifndef TEST_EXECUTE_H
#define TEST_EXECUTE_H

#include <check.h>

Suite *execute_suite (void);

#endif

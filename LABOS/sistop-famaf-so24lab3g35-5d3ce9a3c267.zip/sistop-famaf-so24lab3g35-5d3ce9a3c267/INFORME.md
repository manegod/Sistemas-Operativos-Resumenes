# Informe - Lab3 - wolOS

#### Integrantes: 
 Francisco Asís - María Luz Varas - Lautaro Gastón Peralta - Sanchez Santiago Ezequiel
 
### Primera parte 
 
* ¿Qué política de planificación utiliza `xv6-riscv` para elegir el próximo proceso a ejecutarse?

        Utiliza la política de planificación Round Robin (corre un proceso por una pequeña cantidad de tiempo. 
        Una vez cumplido ese tiempo sigue con el proximo proceso).
        En este contexto, se utiliza la funcion SCHEDULER, que busca en la tabla de procesos un proceso que 
        este en estado RUNNABLE (p->state == RUNNABLE) y lo ejecuta a través de la función SWTCH. 
        Cada proceso se ejecuta por turnos. Para designarlos se utilizan locks (p->lock). Esta política se 
        caracteriza por tener buen tiempo de respuesta (diferencia entre el momento en que el proceso llega al 
        sistema y el momento en el que se lo planifica para comenzar) 
        pero mal turnaround time (cuánto tarda el proceso en completarse).
 
 * ¿Cúales son los estados en los que un proceso puede permanecer en xv6-riscv y qué los hace cambiar de estado?

 		Los estados que puede tomar un proceso estan definidos en proc.h de la forma: enum procstate { UNUSED, 
 		USED, SLEEPING, RUNNABLE, RUNNING, ZOMBIE }; Cada proceso tiene uno de estos estados y cambia a traves 
 		del cumplimiento o no de condiciones. Las trancisiones de estado pueden ser dadas por syscalls o 
 		interrupciones del temporizador.

		Un proceso que esta en RUNNABLE cuendo el planificador lo decida empieza a ejecutarse y cambia a  estado 
		RUNNING, estando en RUNNING puede pasar a RUNNABLE de nuevo si hace una llamada a yied o si se le acabo 
		el tiempo de quantum. Otro estado que puede pasar desde RUNNING es a SLEEPING si necesita informacion 
		de otro pocesos o del sistema operativo y se llama a la funcion sleep, luego cuando ya se consiguio la 
		informacion se llama a wakeup y pasa a RUNNABLE. Cuando un proceso esta en RUNNING y se llama a exit 
		el proceso pasa a estando ZOMBIE que luego si se llama a wait pasa a UNUSED.
	    
 
 * ¿Qué es un *quantum*? ¿Dónde se define en el código? ¿Cuánto dura un *quantum* en `xv6-riscv`?

		Un quantum es un intervalo de tiempo que limita la ejecución de cada proceso. Se lo utiliza para 
		alternar entre éstos y se mide en ciclos.
		En el archivo start.c, la funcion timerinit() maneja las interrupciones del clock del CPU.

		int interval = 1000000; // cycles; about 1/10th second in qemu.
		Esta línea nos dice que cada proceso tiene 1.000.000 de ciclos que duran aproximadamente 1/10 segundos 
		(en QEMU).
		

* ¿En qué parte del código ocurre el cambio de contexto en `xv6-riscv`? ¿En qué funciones un proceso deja de ser ejecutado? ¿En qué funciones se elige el nuevo proceso a ejecutar?

		En el archivo proc.c, el cambio de contexto ocurre dentro de la funcion scheduler (explicitamente en la 
		funcion swtch). La funcion scheduler se encarga de "elegir" el nuevo proceso a ejecutar (recorre la 
		tabla de procesos buscando uno en estado RUNNABLE), adquiere el lock, cambia el estado de la funcion de 
		RUNNABLE a RUNNING y asigna el proceso al cpu. Luego se llama a la funcion swtch que es la encargada de 
		guardar los registros RISC-V del proceso antiguo y cargar los del nuevo. Para frenar la ejecucion de un 
		proceso se pueden usar las funciones sleep (para cuando un proceso necesita que ocurra algo más, como 
		un I/O), yield (cede el CPU de forma voluntaria) y exit (para cuando el proceso finaliza su ejecución).


* ¿El cambio de contexto consume tiempo de un *quantum*?

		El cambio de contexto consume tiempo de CPU, ya que implica guardar los registros del proceso actual y 
		cargar los del nuevo. La función swtch se encarga de este proceso, y el tiempo consumido depende del 
		costo de almacenar y restaurar dichos registros.


## Segunda Parte

### Experimento 1:
 
 * Describa los parámetros de los programas cpubench e iobench para este experimento (o sea, los define al principio y el valor de N. Tener en cuenta que podrían cambiar en experimentos futuros, pero que si lo hacen los resultados ya no serán comparables).

        ➡︎ IOBENCH:
        → parametro de entradas:
            ✱N: Es el numero de iteraciones para el bench, este mismo servirá para determinar cuantas veces 
            se ejecutará el ciclo de I/O generadas por io_ops.
        → parametro de salidas:
            ✱pid: Identificador del proceso en ejecución.
            ✱[iobench] : Nombre del programa.
            ✱metrica_original_io: Nombre de la métrica de I/O utilizada.
            ✱total_iops: Total de operaciones de I/O realizadas. (2 * IO_EXPERIMENT_LEN)
            ✱start_tick: ticks que representan el inicio de iteracion de I/O.
            ✱elapsed_ticks:ticks que representan el tiempo transcurrido en la iteracion de I/O.
            
        ➡︎ CPUBENCH:
        → parametro de entradas:
            ✱N: Igual que iobench, solamente que en este caso se refiere a la cantidad de veces a ejecutar el
            ciclo de ops de CPU.
        → parametro de salidas:
            ✱pid: Identificador del proceso en ejecución.
            ✱[cpubench]: Nombre del programa.
            ✱metrica_original_cpu: Nombre de la métrica de CPU utilizada.
            ✱total_ops: Total de operaciones de CPU realizadas.
            ✱start_tick: ticks que representan el inicio de iteracion de CPU.
            ✱elapsed_ticks: ticks que representan el tiempo transcurrido en la iteracion de CPU.

 * ¿Los procesos se ejecutan en paralelo? ¿En promedio, qué proceso o procesos se ejecutan primero? Hacer una observación cualitativa.

        Los procesos no se ejecutan en paralelo, sino que se ejecutan de manera concurrente alternando entre 
        procesos por medio de cambios de contextos.
        En promedio, no hay un proceso o procesos que se ejecutan primero, debido a que el scheduler utiliza 
        Round-Robin. De todas formas los procesos de iobench pueden llegar a ejecutarse primero ya que el 
        tiempo de espera de los procesos de cpubench es mayor.

 * ¿Cambia el rendimiento de los procesos iobound con respecto a la cantidad y tipo de procesos que se estén ejecutando en paralelo? ¿Por qué?

        Si, el rendimiento de los procesos iobound cambia respecto a la cantidad y tipo de procesos que se 
        esten ejecutando en "paralelo", esto por que los procesos iobound dependen de la cantidad de 
        operaciones de I/O que se realicen (cuando seleccionamos un N arbitrario), y si hay procesos cpubound 
        ejecutandose en paralelo, estos pueden llegar a consumir mas tiempo de CPU, lo que puede llegar a 
        disminuir el rendimiento de los procesos iobound.

* ¿Cambia el rendimiento de los procesos cpubound con respecto a la cantidad y tipo de procesos que se estén ejecutando en paralelo? ¿Por qué?

        El rendimiento cambia debido a que los procesos cpubound dependen del número de núcleos disponibles y de la carga del sistema.
        Si hay varios procesos cpubound ejecutandose en paralelo disminuye el rendimiento dado que los mismos están compartiendo los recursos del sistema.

* ¿Es adecuado comparar la cantidad de operaciones de cpu con la cantidad de operaciones iobound?

        No pueden compararse de manera directa dado que cada una de las operaciones utiliza y está
        limitada por diferentes recursos, y su rendimiento no se mide de la misma manera. Además, 
        las operaciones cpubound están en términos de ciclos de cpu mientras que las iobound en tiempo de latencia.



Mediciones
---

### Sin modificar el quantum
 
    $ iobench 10 &

| PID | Nombre   | Métrica          | total_iops | start_ticks | elapsed_ticks |
|:-----:|:----------:|:------------------:|:------------:|:-------------:|:---------------:|
| 4   | [iobench]| metrica_original_io   | 1024       | 80          | 16            |
| 4   | [iobench]| metrica_original_io   | 1024       | 96          | 14            |
| 4   | [iobench]| metrica_original_io   | 1024       | 110         | 15            |
| 4   | [iobench]| metrica_original_io   | 1024       | 125         | 15            |
| 4   | [iobench]| metrica_original_io   | 1024       | 140         | 15            |
| 4   | [iobench]| metrica_original_io   | 1024       | 155         | 15            |
| 4   | [iobench]| metrica_original_io   | 1024       | 170         | 14            |
| 4   | [iobench]| metrica_original_io   | 1024       | 184         | 15            |
| 4   | [iobench]| metrica_original_io   | 1024       | 199         | 15            |
| 4   | [iobench]| metrica_original_io   | 1024       | 214         | 14            |

    $ iobench 10 &; iobench 10 &; iobench 10 &;

| PID | Nombre   | Métrica          | total_iops | start_ticks | elapsed_ticks |
|:-----:|:----------:|:------------------:|:------------:|:-------------:|:---------------:|
| 11  | [iobench]| metrica_original_io   | 1024       | 4961        | 11            |
| 8   | [iobench]| metrica_original_io   | 1024       | 4961        | 16            |
| 10  | [iobench]| metrica_original_io   | 1024       | 4961        | 16            |
| 11  | [iobench]| metrica_original_io   | 1024       | 4972        | 12            |
| 10  | [iobench]| metrica_original_io   | 1024       | 4977        | 9             |
| 8   | [iobench]| metrica_original_io   | 1024       | 4977        | 13            |
| 10  | [iobench]| metrica_original_io   | 1024       | 4986        | 11            |
| 8   | [iobench]| metrica_original_io   | 1024       | 4990        | 9             |
| 11  | [iobench]| metrica_original_io   | 1024       | 4984        | 16            |
| 11  | [iobench]| metrica_original_io   | 1024       | 5000        | 11            |
| 8   | [iobench]| metrica_original_io   | 1024       | 4999        | 14            |
| 10  | [iobench]| metrica_original_io   | 1024       | 4997        | 16            |
| 8   | [iobench]| metrica_original_io   | 1024       | 5013        | 7             |
| 11  | [iobench]| metrica_original_io   | 1024       | 5011        | 14            |
| 10  | [iobench]| metrica_original_io   | 1024       | 5013        | 16            |
| 8   | [iobench]| metrica_original_io   | 1024       | 5020        | 13            |
| 11  | [iobench]| metrica_original_io   | 1024       | 5025        | 11            |
| 11  | [iobench]| metrica_original_io   | 1024       | 5036        | 7             |
| 8   | [iobench]| metrica_original_io   | 1024       | 5033        | 12            |
| 10  | [iobench]| metrica_original_io   | 1024       | 5029        | 22            |
| 11  | [iobench]| metrica_original_io   | 1024       | 5043        | 12            |
| 8   | [iobench]| metrica_original_io   | 1024       | 5045        | 10            |
| 10  | [iobench]| metrica_original_io   | 1024       | 5051        | 11            |
| 8   | [iobench]| metrica_original_io   | 1024       | 5055        | 10            |
| 11  | [iobench]| metrica_original_io   | 1024       | 5055        | 14            |
| 10  | [iobench]| metrica_original_io   | 1024       | 5062        | 11            |
| 11  | [iobench]| metrica_original_io   | 1024       | 5069        | 10            |
| 8   | [iobench]| metrica_original_io   | 1024       | 5065        | 16            |
| 10  | [iobench]| metrica_original_io   | 1024       | 5073        | 14            |
| 10  | [iobench]| metrica_original_io   | 1024       | 5087        | 15            |

    $ cpubench 10 &;

| PID | Nombre    | Métrica          | total_iops | start_ticks | elapsed_ticks |
|:-----:|:-----------:|:------------------:|:------------:|:-------------:|:---------------:|
| 15  | [cpubench]| metrica_original_cpu  | 536832     | 8067        | 9             |
| 15  | [cpubench]| metrica_original_cpu  | 536832     | 8076        | 9             |
| 15  | [cpubench]| metrica_original_cpu  | 536832     | 8085        | 9             |
| 15  | [cpubench]| metrica_original_cpu  | 536832     | 8094        | 9             |
| 15  | [cpubench]| metrica_original_cpu  | 536832     | 8103        | 9             |
| 15  | [cpubench]| metrica_original_cpu  | 536832     | 8112        | 9             |
| 15  | [cpubench]| metrica_original_cpu  | 536832     | 8121        | 9             |
| 15  | [cpubench]| metrica_original_cpu  | 536832     | 8130        | 9             |
| 15  | [cpubench]| metrica_original_cpu  | 536832     | 8139        | 9             |
| 15  | [cpubench]| metrica_original_cpu  | 536832     | 8148        | 8             |

    $ cpubench 10 &; cpubench 10 &; cpubench 10 &

| PID | Nombre    | Métrica          | total_iops | start_ticks | elapsed_ticks |
|:-----:|:-----------:|:------------------:|:------------:|-------------:|:---------------:|
| 19  | [cpubench]| metrica_original_cpu  | 536832     | 9864        | 25            |
| 21  | [cpubench]| metrica_original_cpu  | 536832     | 9866        | 27            |
| 22  | [cpubench]| metrica_original_cpu  | 536832     | 9867        | 27            |
| 19  | [cpubench]| metrica_original_cpu  | 536832     | 9889        | 27            |
| 21  | [cpubench]| metrica_original_cpu  | 536832     | 9893        | 27            |
| 22  | [cpubench]| metrica_original_cpu  | 536832     | 9894        | 27            |
| 19  | [cpubench]| metrica_original_cpu  | 536832     | 9916        | 27            |
| 21  | [cpubench]| metrica_original_cpu  | 536832     | 9920        | 27            |
| 22  | [cpubench]| metrica_original_cpu  | 536832     | 9921        | 27            |
| 19  | [cpubench]| metrica_original_cpu  | 536832     | 9943        | 27            |
| 21  | [cpubench]| metrica_original_cpu  | 536832     | 9947        | 27            |
| 22  | [cpubench]| metrica_original_cpu  | 536832     | 9948        | 27            |
| 19  | [cpubench]| metrica_original_cpu  | 536832     | 9970        | 27            |
| 21  | [cpubench]| metrica_original_cpu  | 536832     | 9974        | 27            |
| 22  | [cpubench]| metrica_original_cpu  | 536832     | 9975        | 27            |
| 19  | [cpubench]| metrica_original_cpu  | 536832     | 9997        | 27            |
| 21  | [cpubench]| metrica_original_cpu  | 536832     | 10001       | 27            |
| 22  | [cpubench]| metrica_original_cpu  | 536832     | 10002       | 27            |
| 19  | [cpubench]| metrica_original_cpu  | 536832     | 10024       | 27            |
| 21  | [cpubench]| metrica_original_cpu  | 536832     | 10028       | 27            |
| 22  | [cpubench]| metrica_original_cpu  | 536832     | 10029       | 27            |
| 19  | [cpubench]| metrica_original_cpu  | 536832     | 10051       | 27            |
| 21  | [cpubench]| metrica_original_cpu  | 536832     | 10055       | 27            |
| 22  | [cpubench]| metrica_original_cpu  | 536832     | 10056       | 27            |
| 19  | [cpubench]| metrica_original_cpu  | 536832     | 10078       | 27            |
| 21  | [cpubench]| metrica_original_cpu  | 536832     | 10082       | 27            |
| 22  | [cpubench]| metrica_original_cpu  | 536832     | 10083       | 27            |
| 19  | [cpubench]| metrica_original_cpu  | 536832     | 10105       | 27            |
| 21  | [cpubench]| metrica_original_cpu  | 536832     | 10109       | 25            |
| 22  | [cpubench]| metrica_original_cpu  | 536832     | 10110       | 25            |

    $ iobench 10 &; cpubench 10 &; cpubench 10 &; cpubench 10 &

| PID | Nombre    | Métrica          | total_iops | start_ticks | elapsed_ticks |
|:-----:|:-----------:|:------------------:|:------------:|:-------------:|:---------------:|
| 28  | [cpubench]| metrica_original_cpu  | 536832     | 37429       | 25            |
| 30  | [cpubench]| metrica_original_cpu  | 536832     | 37431       | 24            |
| 31  | [cpubench]| metrica_original_cpu  | 536832     | 37432       | 27            |
| 28  | [cpubench]| metrica_original_cpu  | 536832     | 37454       | 27            |
| 30  | [cpubench]| metrica_original_cpu  | 536832     | 37458       | 27            |
| 31  | [cpubench]| metrica_original_cpu  | 536832     | 37459       | 27            |
| 28  | [cpubench]| metrica_original_cpu  | 536832     | 37481       | 27            |
| 30  | [cpubench]| metrica_original_cpu  | 536832     | 37485       | 27            |
| 31  | [cpubench]| metrica_original_cpu  | 536832     | 37486       | 27            |
| 28  | [cpubench]| metrica_original_cpu  | 536832     | 37508       | 27            |
| 30  | [cpubench]| metrica_original_cpu  | 536832     | 37512       | 27            |
| 31  | [cpubench]| metrica_original_cpu  | 536832     | 37513       | 27            |
| 28  | [cpubench]| metrica_original_cpu  | 536832     | 37535       | 27            |
| 30  | [cpubench]| metrica_original_cpu  | 536832     | 37539       | 27            |
| 31  | [cpubench]| metrica_original_cpu  | 536832     | 37540       | 27            |
| 28  | [cpubench]| metrica_original_cpu  | 536832     | 37562       | 27            |
| 30  | [cpubench]| metrica_original_cpu  | 536832     | 37566       | 27            |
| 31  | [cpubench]| metrica_original_cpu  | 536832     | 37567       | 27            |
| 28  | [cpubench]| metrica_original_cpu  | 536832     | 37589       | 30            |
| 30  | [cpubench]| metrica_original_cpu  | 536832     | 37593       | 27            |
| 31  | [cpubench]| metrica_original_cpu  | 536832     | 37594       | 27            |
| 28  | [cpubench]| metrica_original_cpu  | 536832     | 37619       | 27            |
| 30  | [cpubench]| metrica_original_cpu  | 536832     | 37620       | 27            |
| 31  | [cpubench]| metrica_original_cpu  | 536832     | 37621       | 27            |
| 28  | [cpubench]| metrica_original_cpu  | 536832     | 37646       | 27            |
| 30  | [cpubench]| metrica_original_cpu  | 536832     | 37647       | 27            |
| 31  | [cpubench]| metrica_original_cpu  | 536832     | 37648       | 27            |
| 28  | [cpubench]| metrica_original_cpu  | 536832     | 37673       | 27            |
| 31  | [cpubench]| metrica_original_cpu  | 536832     | 37675       | 26            |
| 30  | [cpubench]| metrica_original_cpu  | 536832     | 37674       | 27            |
| 26  | [iobench] | metrica_original_io   | 1024       | 37439       | 277           |
| 26  | [iobench] | metrica_original_io   | 1024       | 37716       | 15            |
| 26  | [iobench] | metrica_original_io   | 1024       | 37731       | 15            |
| 26  | [iobench] | metrica_original_io   | 1024       | 37746       | 16            |
| 26  | [iobench] | metrica_original_io   | 1024       | 37762       | 15            |
| 26  | [iobench] | metrica_original_io   | 1024       | 37777       | 15            |
| 26  | [iobench] | metrica_original_io   | 1024       | 37792       | 14            |
| 26  | [iobench] | metrica_original_io   | 1024       | 37806       | 15            |
| 26  | [iobench] | metrica_original_io   | 1024       | 37821       | 15            |
| 26  | [iobench] | metrica_original_io   | 1024       | 37836       | 15            |

    $ cpubench 10 &; iobench 10 &; iobench 10 &; iobench 10 &

| PID | Nombre    | Métrica          | total_iops | start_ticks | elapsed_ticks |
|:-----:|:-----------:|:------------------:|:------------:|:-------------:|:---------------:|
| 5   | [cpubench]| metrica_original_cpu  | 536832     | 10          | 10            |
| 5   | [cpubench]| metrica_original_cpu  | 536832     | 20          | 9             |
| 5   | [cpubench]| metrica_original_cpu  | 536832     | 29          | 9             |
| 5   | [cpubench]| metrica_original_cpu  | 536832     | 38          | 10            |
| 5   | [cpubench]| metrica_original_cpu  | 536832     | 48          | 9             |
| 5   | [cpubench]| metrica_original_cpu  | 536832     | 57          | 9             |
| 5   | [cpubench]| metrica_original_cpu  | 536832     | 66          | 9             |
| 5   | [cpubench]| metrica_original_cpu  | 536832     | 75          | 9             |
| 5   | [cpubench]| metrica_original_cpu  | 536832     | 84          | 9             |
| 5   | [cpubench]| metrica_original_cpu  | 536832     | 93          | 9             |
| 10  | [iobench] | metrica_original_io   | 1024       | 12          | 98            |
| 9   | [iobench] | metrica_original_io   | 1024       | 12          | 102           |
| 7   | [iobench] | metrica_original_io   | 1024       | 12          | 106           |
| 10  | [iobench] | metrica_original_io   | 1024       | 110         | 12            |
| 9   | [iobench] | metrica_original_io   | 1024       | 114         | 14            |
| 10  | [iobench] | metrica_original_io   | 1024       | 122         | 10            |
| 7   | [iobench] | metrica_original_io   | 1024       | 118         | 14            |
| 9   | [iobench] | metrica_original_io   | 1024       | 128         | 13            |
| 7   | [iobench] | metrica_original_io   | 1024       | 132         | 10            |
| 10  | [iobench] | metrica_original_io   | 1024       | 132         | 16            |
| 9   | [iobench] | metrica_original_io   | 1024       | 141         | 11            |
| 7   | [iobench] | metrica_original_io   | 1024       | 142         | 16            |
| 9   | [iobench] | metrica_original_io   | 1024       | 152         | 10            |
| 10  | [iobench] | metrica_original_io   | 1024       | 148         | 14            |
| 10  | [iobench] | metrica_original_io   | 1024       | 162         | 10            |
| 7   | [iobench] | metrica_original_io   | 1024       | 158         | 14            |
| 9   | [iobench] | metrica_original_io   | 1024       | 162         | 14            |
| 10  | [iobench] | metrica_original_io   | 1024       | 172         | 12            |
| 9   | [iobench] | metrica_original_io   | 1024       | 176         | 10            |
| 7   | [iobench] | metrica_original_io   | 1024       | 172         | 15            |
| 10  | [iobench] | metrica_original_io   | 1024       | 184         | 10            |
| 7   | [iobench] | metrica_original_io   | 1024       | 187         | 11            |
| 10  | [iobench] | metrica_original_io   | 1024       | 194         | 10            |
| 9   | [iobench] | metrica_original_io   | 1024       | 186         | 24            |
| 10  | [iobench] | metrica_original_io   | 1024       | 204         | 9             |
| 7   | [iobench] | metrica_original_io   | 1024       | 198         | 15            |
| 9   | [iobench] | metrica_original_io   | 1024       | 210         | 8             |
| 7   | [iobench] | metrica_original_io   | 1024       | 213         | 8             |
| 9   | [iobench] | metrica_original_io   | 1024       | 218         | 9             |
| 7   | [iobench] | metrica_original_io   | 1024       | 221         | 12            |

### Con modificacion en el quantum (10 veces mas pequeño)

    $ iobench 10 &

| PID | Nombre    | Métrica          | total_iops | start_ticks | elapsed_ticks |
|:-----:|:-----------:|:------------------:|:------------:|:-------------:|:---------------:|
| 4   | [iobench] | metrica_original_io   | 1024       | 758         | 165           |
| 4   | [iobench] | metrica_original_io   | 1024       | 923         | 171           |
| 4   | [iobench] | metrica_original_io   | 1024       | 1094        | 159           |
| 4   | [iobench] | metrica_original_io   | 1024       | 1254        | 158           |
| 4   | [iobench] | metrica_original_io   | 1024       | 1412        | 157           |
| 4   | [iobench] | metrica_original_io   | 1024       | 1569        | 158           |
| 4   | [iobench] | metrica_original_io   | 1024       | 1728        | 155           |
| 4   | [iobench] | metrica_original_io   | 1024       | 1883        | 154           |
| 4   | [iobench] | metrica_original_io   | 1024       | 2038        | 152           |
| 4   | [iobench] | metrica_original_io   | 1024       | 2191        | 150           |

    $ iobench 10 &; iobench 10 &; iobench 10 &;

| PID | Nombre    | Métrica          | total_iops | start_ticks | elapsed_ticks |
|:-----:|:-----------:|:------------------:|:------------:|:-------------:|:---------------:|
| 5   | [iobench] | metrica_original_io   | 1024       | 128         | 86            |
| 9   | [iobench] | metrica_original_io   | 1024       | 129         | 109           |
| 7   | [iobench] | metrica_original_io   | 1024       | 128         | 131           |
| 7   | [iobench] | metrica_original_io   | 1024       | 259         | 77            |
| 5   | [iobench] | metrica_original_io   | 1024       | 215         | 143           |
| 9   | [iobench] | metrica_original_io   | 1024       | 239         | 161           |
| 7   | [iobench] | metrica_original_io   | 1024       | 336         | 129           |
| 5   | [iobench] | metrica_original_io   | 1024       | 359         | 142           |
| 9   | [iobench] | metrica_original_io   | 1024       | 400         | 142           |
| 7   | [iobench] | metrica_original_io   | 1024       | 465         | 98            |
| 5   | [iobench] | metrica_original_io   | 1024       | 502         | 134           |
| 9   | [iobench] | metrica_original_io   | 1024       | 544         | 112           |
| 7   | [iobench] | metrica_original_io   | 1024       | 564         | 118           |
| 5   | [iobench] | metrica_original_io   | 1024       | 637         | 128           |
| 9   | [iobench] | metrica_original_io   | 1024       | 658         | 141           |
| 7   | [iobench] | metrica_original_io   | 1024       | 683         | 134           |
| 5   | [iobench] | metrica_original_io   | 1024       | 765         | 118           |
| 7   | [iobench] | metrica_original_io   | 1024       | 818         | 130           |
| 9   | [iobench] | metrica_original_io   | 1024       | 800         | 161           |
| 5   | [iobench] | metrica_original_io   | 1024       | 885         | 99            |
| 9   | [iobench] | metrica_original_io   | 1024       | 962         | 112           |
| 5   | [iobench] | metrica_original_io   | 1024       | 984         | 113           |
| 7   | [iobench] | metrica_original_io   | 1024       | 949         | 171           |
| 9   | [iobench] | metrica_original_io   | 1024       | 1074        | 107           |
| 7   | [iobench] | metrica_original_io   | 1024       | 1120        | 99            |
| 9   | [iobench] | metrica_original_io   | 1024       | 1182        | 113           |
| 5   | [iobench] | metrica_original_io   | 1024       | 1097        | 198           |
| 7   | [iobench] | metrica_original_io   | 1024       | 1220        | 121           |
| 9   | [iobench] | metrica_original_io   | 1024       | 1295        | 91            |
| 5   | [iobench] | metrica_original_io   | 1024       | 1296        | 95            |

    $ cpubench 10 &;

| PID | Nombre    | Métrica          | total_iops | start_ticks | elapsed_ticks |
|:-----:|:-----------:|:------------------:|:------------:|:-------------:|:---------------:|
| 13  | [cpubench] | metrica_original_cpu  | 536832     | 8986        | 91            |
| 13  | [cpubench] | metrica_original_cpu  | 536832     | 9078        | 91            |
| 13  | [cpubench] | metrica_original_cpu  | 536832     | 9170        | 91            |
| 13  | [cpubench] | metrica_original_cpu  | 536832     | 9262        | 91            |
| 13  | [cpubench] | metrica_original_cpu  | 536832     | 9353        | 92            |
| 13  | [cpubench] | metrica_original_cpu  | 536832     | 9445        | 91            |
| 13  | [cpubench] | metrica_original_cpu  | 536832     | 9537        | 91            |
| 13  | [cpubench] | metrica_original_cpu  | 536832     | 9628        | 93            |
| 13  | [cpubench] | metrica_original_cpu  | 536832     | 9722        | 91            |
| 13  | [cpubench] | metrica_original_cpu  | 536832     | 9814        | 94            |

    $ cpubench 10 &; cpubench 10 &; cpubench 10 &

| PID | Nombre     | Métrica          | total_iops | start_ticks | elapsed_ticks |
|:-----:|:------------:|:------------------:|:------------:|:-------------:|:---------------:|
| 5   | [cpubench] | metrica_original_cpu  | 536832     | 142         | 279           |
| 7   | [cpubench] | metrica_original_cpu  | 536832     | 143         | 279           |
| 8   | [cpubench] | metrica_original_cpu  | 536832     | 144         | 279           |
| 5   | [cpubench] | metrica_original_cpu  | 536832     | 421         | 273           |
| 7   | [cpubench] | metrica_original_cpu  | 536832     | 422         | 273           |
| 8   | [cpubench] | metrica_original_cpu  | 536832     | 423         | 273           |
| 5   | [cpubench] | metrica_original_cpu  | 536832     | 697         | 273           |
| 7   | [cpubench] | metrica_original_cpu  | 536832     | 698         | 273           |
| 8   | [cpubench] | metrica_original_cpu  | 536832     | 699         | 273           |
| 5   | [cpubench] | metrica_original_cpu  | 536832     | 971         | 276           |
| 7   | [cpubench] | metrica_original_cpu  | 536832     | 970         | 276           |
| 8   | [cpubench] | metrica_original_cpu  | 536832     | 975         | 279           |
| 5   | [cpubench] | metrica_original_cpu  | 536832     | 1247        | 273           |
| 7   | [cpubench] | metrica_original_cpu  | 536832     | 1249        | 273           |
| 8   | [cpubench] | metrica_original_cpu  | 536832     | 1254        | 276           |
| 5   | [cpubench] | metrica_original_cpu  | 536832     | 1525        | 273           |
| 7   | [cpubench] | metrica_original_cpu  | 536832     | 1523        | 273           |
| 8   | [cpubench] | metrica_original_cpu  | 536832     | 1530        | 276           |
| 5   | [cpubench] | metrica_original_cpu  | 536832     | 1801        | 273           |
| 7   | [cpubench] | metrica_original_cpu  | 536832     | 1799        | 273           |
| 8   | [cpubench] | metrica_original_cpu  | 536832     | 1806        | 279           |
| 5   | [cpubench] | metrica_original_cpu  | 536832     | 2077        | 273           |
| 7   | [cpubench] | metrica_original_cpu  | 536832     | 2072        | 273           |
| 8   | [cpubench] | metrica_original_cpu  | 536832     | 2085        | 273           |
| 5   | [cpubench] | metrica_original_cpu  | 536832     | 2350        | 273           |
| 7   | [cpubench] | metrica_original_cpu  | 536832     | 2348        | 273           |
| 8   | [cpubench] | metrica_original_cpu  | 536832     | 2361        | 273           |
| 5   | [cpubench] | metrica_original_cpu  | 536832     | 2626        | 274           |
| 7   | [cpubench] | metrica_original_cpu  | 536832     | 2621        | 273           |
| 8   | [cpubench] | metrica_original_cpu  | 536832     | 2637        | 267           |

    $ iobench 10 &; cpubench 10 &; cpubench 10 &; cpubench 10 &

| PID | Nombre     | Métrica          | total_iops | start_ticks | elapsed_ticks |
|:-----:|:------------:|:------------------:|:------------:|:-------------:|:---------------:|
| 16  | [cpubench] | metrica_original_cpu  | 536832     | 14803       | 273           |
| 17  | [cpubench] | metrica_original_cpu  | 536832     | 14804       | 276           |
| 14  | [cpubench] | metrica_original_cpu  | 536832     | 14802       | 285           |
| 16  | [cpubench] | metrica_original_cpu  | 536832     | 15076       | 276           |
| 17  | [cpubench] | metrica_original_cpu  | 536832     | 15083       | 273           |
| 14  | [cpubench] | metrica_original_cpu  | 536832     | 15090       | 285           |
| 16  | [cpubench] | metrica_original_cpu  | 536832     | 15352       | 276           |
| 17  | [cpubench] | metrica_original_cpu  | 536832     | 15359       | 273           |
| 14  | [cpubench] | metrica_original_cpu  | 536832     | 15378       | 285           |
| 16  | [cpubench] | metrica_original_cpu  | 536832     | 15628       | 273           |
| 17  | [cpubench] | metrica_original_cpu  | 536832     | 15632       | 276           |
| 14  | [cpubench] | metrica_original_cpu  | 536832     | 15666       | 282           |
| 16  | [cpubench] | metrica_original_cpu  | 536832     | 15901       | 273           |
| 17  | [cpubench] | metrica_original_cpu  | 536832     | 15908       | 276           |
| 14  | [cpubench] | metrica_original_cpu  | 536832     | 15951       | 285           |
| 16  | [cpubench] | metrica_original_cpu  | 536832     | 16177       | 273           |
| 17  | [cpubench] | metrica_original_cpu  | 536832     | 16184       | 273           |
| 14  | [cpubench] | metrica_original_cpu  | 536832     | 16239       | 285           |
| 16  | [cpubench] | metrica_original_cpu  | 536832     | 16453       | 273           |
| 17  | [cpubench] | metrica_original_cpu  | 536832     | 16460       | 273           |
| 14  | [cpubench] | metrica_original_cpu  | 536832     | 16524       | 285           |
| 16  | [cpubench] | metrica_original_cpu  | 536832     | 16726       | 276           |
| 17  | [cpubench] | metrica_original_cpu  | 536832     | 16736       | 276           |
| 14  | [cpubench] | metrica_original_cpu  | 536832     | 16812       | 288           |
| 16  | [cpubench] | metrica_original_cpu  | 536832     | 17002       | 273           |
| 17  | [cpubench] | metrica_original_cpu  | 536832     | 17012       | 276           |
| 14  | [cpubench] | metrica_original_cpu  | 536832     | 17100       | 285           |
| 16  | [cpubench] | metrica_original_cpu  | 536832     | 17275       | 276           |
| 17  | [cpubench] | metrica_original_cpu  | 536832     | 17288       | 271           |
| 14  | [cpubench] | metrica_original_cpu  | 536832     | 17388       | 207           |
| 12  | [iobench]  | metrica_original_io   | 1024       | 14811       | 2889          |
| 12  | [iobench]  | metrica_original_io   | 1024       | 17700       | 142           |
| 12  | [iobench]  | metrica_original_io   | 1024       | 17842       | 144           |
| 12  | [iobench]  | metrica_original_io   | 1024       | 17986       | 143           |
| 12  | [iobench]  | metrica_original_io   | 1024       | 18130       | 142           |
| 12  | [iobench]  | metrica_original_io   | 1024       | 18273       | 144           |
| 12  | [iobench]  | metrica_original_io   | 1024       | 18417       | 142           |
| 12  | [iobench]  | metrica_original_io   | 1024       | 18560       | 143           |
| 12  | [iobench]  | metrica_original_io   | 1024       | 18703       | 142           |
| 12  | [iobench]  | metrica_original_io   | 1024       | 18845       | 142           |

    $ cpubench 10 &; iobench 10 &; iobench 10 &; iobench 10 &

| PID | Nombre       | Métrica           | total_iops | start_ticks | elapsed_ticks |
|:-----:|:--------------:|:-------------------:|:------------:|:-------------:|:----------------:|
| 21  | [cpubench]  | metrica_original_cpu   | 536832     | 28681       | 101            |
| 21  | [cpubench]  | metrica_original_cpu   | 536832     | 28783       | 98             |
| 21  | [cpubench]  | metrica_original_cpu   | 536832     | 28882       | 110            |
| 21  | [cpubench]  | metrica_original_cpu   | 536832     | 28993       | 96             |
| 21  | [cpubench]  | metrica_original_cpu   | 536832     | 29089       | 98             |
| 21  | [cpubench]  | metrica_original_cpu   | 536832     | 29188       | 102            |
| 21  | [cpubench]  | metrica_original_cpu   | 536832     | 29290       | 98             |
| 21  | [cpubench]  | metrica_original_cpu   | 536832     | 29389       | 98             |
| 21  | [cpubench]  | metrica_original_cpu   | 536832     | 29487       | 96             |
| 21  | [cpubench]  | metrica_original_cpu   | 536832     | 29584       | 98             |
| 25  | [iobench]   | metrica_original_io    | 1024       | 28682       | 1041           |
| 26  | [iobench]   | metrica_original_io    | 1024       | 28688       | 1057           |
| 23  | [iobench]   | metrica_original_io    | 1024       | 28682       | 1097           |
| 25  | [iobench]   | metrica_original_io    | 1024       | 29724       | 118            |
| 26  | [iobench]   | metrica_original_io    | 1024       | 29747       | 128            |
| 23  | [iobench]   | metrica_original_io    | 1024       | 29779       | 111            |
| 26  | [iobench]   | metrica_original_io    | 1024       | 29875       | 109            |
| 23  | [iobench]   | metrica_original_io    | 1024       | 29890       | 104            |
| 25  | [iobench]   | metrica_original_io    | 1024       | 29843       | 182            |
| 26  | [iobench]   | metrica_original_io    | 1024       | 29984       | 94             |
| 23  | [iobench]   | metrica_original_io    | 1024       | 29994       | 146            |
| 25  | [iobench]   | metrica_original_io    | 1024       | 30026       | 114            |
| 26  | [iobench]   | metrica_original_io    | 1024       | 30079       | 114            |
| 25  | [iobench]   | metrica_original_io    | 1024       | 30140       | 101            |
| 23  | [iobench]   | metrica_original_io    | 1024       | 30140       | 140            |
| 26  | [iobench]   | metrica_original_io    | 1024       | 30194       | 106            |
| 25  | [iobench]   | metrica_original_io    | 1024       | 30241       | 118            |
| 26  | [iobench]   | metrica_original_io    | 1024       | 30300       | 97             |
| 23  | [iobench]   | metrica_original_io    | 1024       | 30283       | 143            |
| 25  | [iobench]   | metrica_original_io    | 1024       | 30359       | 124            |
| 26  | [iobench]   | metrica_original_io    | 1024       | 30399       | 119            |
| 23  | [iobench]   | metrica_original_io    | 1024       | 30426       | 133            |
| 25  | [iobench]   | metrica_original_io    | 1024       | 30483       | 109            |
| 26  | [iobench]   | metrica_original_io    | 1024       | 30518       | 105            |
| 23  | [iobench]   | metrica_original_io    | 1024       | 30560       | 119            |
| 25  | [iobench]   | metrica_original_io    | 1024       | 30592       | 87             |
| 26  | [iobench]   | metrica_original_io    | 1024       | 30626       | 141            |
| 23  | [iobench]   | metrica_original_io    | 1024       | 30679       | 93             |
| 25  | [iobench]   | metrica_original_io    | 1024       | 30680       | 118            |
| 23  | [iobench]   | metrica_original_io    | 1024       | 30772       | 132            |


### Experimento 2:

Métrica nueva implementada en iobench:

    metric = (total_iops * 1000) / elapsed_ticks; 

Métrica nueva implementada en cpubench:

    metric = (total_cpu_kops * 1000) / elapsed_ticks;

* ¿Fue necesario modificar las métricas para que los resultados fueran comparables? ¿Por qué?

        Sí, dado que la métrica original no tenía en cuenta el tiempo de ejecución de las operaciones.

* ¿Qué cambios se observan con respecto al experimento anterior? ¿Qué comportamientos se mantienen iguales?

        Observamos que al decrementar el número del Quantum, a ambos procesos tanto iobench como cpubench les tomaba más tiempo(ticks) completar sus operaciones. En el siguiente link se encuentran los gráficos comparativos.
        Se mantuvo bajo el mismo efecto que sigue siendo más efectivo los procesos cpubound en tareas de cómputo intensivo mientras que los iobound de accesos más rápidos a los recursos I/O.

    [GRÁFICOS COMPARATIVOS](https://docs.google.com/spreadsheets/d/1l4ilsJifcmSlfR1kK0chO08-PTIfhUhJ4Nvbu-LbyCY/edit?gid=0#gid=0)

* ¿Con un quantum más pequeño, se ven beneficiados los procesos iobound o los procesos cpubound?

        Se ven beneficiados los procesos iobound dado que al acortar el quantum el sistema operativo puede realizar los cambios de contexto más rápido. Caso contrario para los procesos cpubound debido a que no obtienen suficiente tiempo continuo de cpu y por ende resulta en un aumento en el tiempo de ejecución.


Mediciones
---

### Quantum = 1000

    $ iobench 10 &

| PID | Nombre    | Métrica           | ops_per_second | start_tick | elapsed_ticks |
|:-----:|:-----------:|:-------------------:|:----------------:|:------------:|:---------------:|
| 4   | [iobench] | metrica_nueva_io  | 37             | 42732      | 27602         |
| 4   | [iobench] | metrica_nueva_io  | 39             | 70480      | 26169         |
| 4   | [iobench] | metrica_nueva_io  | 39             | 96772      | 26095         |
| 4   | [iobench] | metrica_nueva_io  | 39             | 123005     | 25873         |
| 4   | [iobench] | metrica_nueva_io  | 39             | 149031     | 26044         |
| 4   | [iobench] | metrica_nueva_io  | 39             | 175207     | 26214         |
| 4   | [iobench] | metrica_nueva_io  | 38             | 201526     | 26896         |
| 4   | [iobench] | metrica_nueva_io  | 39             | 228545     | 25920         |
| 4   | [iobench] | metrica_nueva_io  | 40             | 254487     | 25112         |
| 4   | [iobench] | metrica_nueva_io  | 36             | 279627     | 27838         |

    $ iobench 10 &; iobench 10 &; iobench 10 &

|  PID  |   Nombre   |      Métrica      | ops_per_second | start_tick | elapsed_ticks |
|:-----:|:----------:|:-----------------:|:--------------:|:----------:|:-------------:|
|  10   | [iobench]  | metrica_nueva_io  |       35       |  2325864   |     29005     |
|   8   | [iobench]  | metrica_nueva_io  |       34       |  2325818   |     29520     |
|  11   | [iobench]  | metrica_nueva_io  |       32       |  2325949   |     31642     |
|  10   | [iobench]  | metrica_nueva_io  |       38       |  2355134   |     26925     |
|   8   | [iobench]  | metrica_nueva_io  |       37       |  2355604   |     27625     |
|  11   | [iobench]  | metrica_nueva_io  |       37       |  2357772   |     27334     |
|  10   | [iobench]  | metrica_nueva_io  |       35       |  2382333   |     28685     |
|   8   | [iobench]  | metrica_nueva_io  |       34       |  2383520   |     29917     |
|  11   | [iobench]  | metrica_nueva_io  |       33       |  2385394   |     30968     |
|  10   | [iobench]  | metrica_nueva_io  |       33       |  2411290   |     30401     |
|   8   | [iobench]  | metrica_nueva_io  |       34       |  2413709   |     29518     |
|  11   | [iobench]  | metrica_nueva_io  |       33       |  2416648   |     30665     |
|  10   | [iobench]  | metrica_nueva_io  |       34       |  2441952   |     29371     |
|   8   | [iobench]  | metrica_nueva_io  |       36       |  2443762   |     28134     |
|  11   | [iobench]  | metrica_nueva_io  |       37       |  2447515   |     26955     |
|  10   | [iobench]  | metrica_nueva_io  |       36       |  2471591   |     27963     |
|   8   | [iobench]  | metrica_nueva_io  |       36       |  2472224   |     27979     |
|  11   | [iobench]  | metrica_nueva_io  |       34       |  2474479   |     29553     |
|  10   | [iobench]  | metrica_nueva_io  |       34       |  2499815   |     29488     |
|   8   | [iobench]  | metrica_nueva_io  |       33       |  2500498   |     30226     |
|  11   | [iobench]  | metrica_nueva_io  |       35       |  2504252   |     29219     |
|   8   | [iobench]  | metrica_nueva_io  |       44       |  2531052   |     22892     |
|  10   | [iobench]  | metrica_nueva_io  |       36       |  2529629   |     27911     |
|  11   | [iobench]  | metrica_nueva_io  |       37       |  2533666   |     27362     |
|   8   | [iobench]  | metrica_nueva_io  |       38       |  2554027   |     26679     |
|  10   | [iobench]  | metrica_nueva_io  |       35       |  2557832   |     28508     |
|  11   | [iobench]  | metrica_nueva_io  |       36       |  2561267   |     28324     |
|   8   | [iobench]  | metrica_nueva_io  |       36       |  2580957   |     28143     |
|  10   | [iobench]  | metrica_nueva_io  |       39       |  2586616   |     26154     |
|  11   | [iobench]  | metrica_nueva_io  |       40       |  2589775   |     25518     |

    $ cpubench 10 &
|  PID  |   Nombre   |      Métrica      | ops_per_second | start_tick | elapsed_ticks |
|:-----:|:----------:|:-----------------:|:--------------:|:----------:|:-------------:|
|  17   | [cpubench] | metrica_nueva_cpu |     14096      |  3484583   |     38083     |
|  17   | [cpubench] | metrica_nueva_cpu |     14975      |  3522845   |     35847     |
|  17   | [cpubench] | metrica_nueva_cpu |     12691      |  3558824   |     42299     |
|  17   | [cpubench] | metrica_nueva_cpu |     18945      |  3601138   |     28336     |
|  17   | [cpubench] | metrica_nueva_cpu |     12582      |  3629602   |     42665     |
|  17   | [cpubench] | metrica_nueva_cpu |     11817      |  3672410   |     45428     |
|  17   | [cpubench] | metrica_nueva_cpu |     11544      |  3717974   |     46502     |
|  17   | [cpubench] | metrica_nueva_cpu |     13894      |  3764584   |     38637     |
|  17   | [cpubench] | metrica_nueva_cpu |     15220      |  3803362   |     35271     |
|  17   | [cpubench] | metrica_nueva_cpu |     12114      |  3838771   |     44312     |

    $ cpubench 10 &; cpubench 10 &; cpubench 10 &
|  PID  |   Nombre   |      Métrica      | ops_per_second | start_tick | elapsed_ticks |
|:-----:|:----------:|:-----------------:|:--------------:|:----------:|:-------------:|
|  21   | [cpubench] | metrica_nueva_cpu |      5307      | 16321299   |    101155     |
|  23   | [cpubench] | metrica_nueva_cpu |      5185      | 16321390   |    103517     |
|  24   | [cpubench] | metrica_nueva_cpu |      4654      | 16321537   |    115332     |
|  21   | [cpubench] | metrica_nueva_cpu |      5339      | 16422755   |     12030     |
|  24   | [cpubench] | metrica_nueva_cpu |      5478      | 16425526   |     97989     |
|  24   | [cpubench] | metrica_nueva_cpu |      5232      | 16437108   |    102590     |
|  23   | [cpubench] | metrica_nueva_cpu |      5426      | 16523808   |     98933     |
|  21   | [cpubench] | metrica_nueva_cpu |      5231      | 16523550   |    102616     |
|  24   | [cpubench] | metrica_nueva_cpu |      4428      | 16540000   |    121223     |
|  23   | [cpubench] | metrica_nueva_cpu |      5398      | 16623077   |     99439     |
|  21   | [cpubench] | metrica_nueva_cpu |      5365      | 16626485   |    100061     |
|  24   | [cpubench] | metrica_nueva_cpu |      5516      | 16661589   |     97311     |
|  23   | [cpubench] | metrica_nueva_cpu |      5444      | 16722794   |     98609     |
|  21   | [cpubench] | metrica_nueva_cpu |      5388      | 16726836   |     99623     |
|  24   | [cpubench] | metrica_nueva_cpu |      5136      | 16759205   |    104505     |
|  23   | [cpubench] | metrica_nueva_cpu |      5351      | 16822070   |    100317     |
|  21   | [cpubench] | metrica_nueva_cpu |      5134      | 16826797   |    104559     |
|  24   | [cpubench] | metrica_nueva_cpu |      4564      | 16864044   |    117607     |
|  23   | [cpubench] | metrica_nueva_cpu |      5353      | 16922746   |    100275     |
|  21   | [cpubench] | metrica_nueva_cpu |      5046      | 16931646   |    106369     |
|  24   | [cpubench] | metrica_nueva_cpu |      4469      | 16981935   |    120115     |
|  23   | [cpubench] | metrica_nueva_cpu |      5169      | 17023378   |    103856     |
|  21   | [cpubench] | metrica_nueva_cpu |      5029      | 17038256   |    106740     |
|  24   | [cpubench] | metrica_nueva_cpu |      4592      | 17102693   |    116890     |
|  23   | [cpubench] | metrica_nueva_cpu |      5310      | 17127528   |    101094     |
|  21   | [cpubench] | metrica_nueva_cpu |      5036      | 17145256   |    106583     |
|  23   | [cpubench] | metrica_nueva_cpu |      5411      | 17228857   |     99197     |
|  24   | [cpubench] | metrica_nueva_cpu |      4705      | 17219979   |    114080     |
|  21   | [cpubench] | metrica_nueva_cpu |      5890      | 17252219   |     91137     |
|  24   | [cpubench] | metrica_nueva_cpu |     10059      | 17334279   |     53368     |

    $ iobench 10 &; cpubench 10 &; cpubench 10 &; cpubench 10 &

|  PID  |   Nombre   |      Métrica      | ops_per_second | start_tick | elapsed_ticks |
|:-----:|:----------:|:-----------------:|:--------------:|:----------:|:-------------:|
|  36   | [iobench]  | metrica_nueva_io  |      13        | 18012523   |     75378     |
|  38   | [cpubench] | metrica_nueva_cpu |     4288       | 18012510   |    125171     |
|  41   | [cpubench] | metrica_nueva_cpu |     4129       | 18012645   |    130007     |
|  40   | [cpubench] | metrica_nueva_cpu |     3637       | 18012699   |    147576     |
|  36   | [iobench]  | metrica_nueva_io  |      14        | 18088282   |     73008     |
|  36   | [iobench]  | metrica_nueva_io  |      14        | 18161771   |     72112     |
|  38   | [cpubench] | metrica_nueva_cpu |     4293       | 18138144   |    125046     |
|  41   | [cpubench] | metrica_nueva_cpu |     4064       | 18143077   |    132070     |
|  40   | [cpubench] | metrica_nueva_cpu |     3745       | 18160756   |    143335     |
|  36   | [iobench]  | metrica_nueva_io  |      14        | 18234258   |     71046     |
|  38   | [cpubench] | metrica_nueva_cpu |     4861       | 18263650   |    110430     |
|  36   | [iobench]  | metrica_nueva_io  |      13        | 18305712   |     75636     |
|  41   | [cpubench] | metrica_nueva_cpu |     4647       | 18275430   |    115518     |
|  40   | [cpubench] | metrica_nueva_cpu |     3959       | 18304532   |    135568     |
|  36   | [iobench]  | metrica_nueva_io  |      13        | 18381616   |     73673     |
|  38   | [cpubench] | metrica_nueva_cpu |     4108       | 18374590   |    130670     |
|  41   | [cpubench] | metrica_nueva_cpu |     4270       | 18391403   |    125699     |
|  36   | [iobench]  | metrica_nueva_io  |      13        | 18455682   |     73662     |
|  40   | [cpubench] | metrica_nueva_cpu |     4457       | 18440588   |    120445     |
|  38   | [cpubench] | metrica_nueva_cpu |     5479       | 18505326   |     97969     |
|  36   | [iobench]  | metrica_nueva_io  |      13        | 18529550   |     76497     |
|  41   | [cpubench] | metrica_nueva_cpu |     4719       | 18517405   |    113755     |
|  36   | [iobench]  | metrica_nueva_io  |      14        | 18607003   |     73098     |
|  40   | [cpubench] | metrica_nueva_cpu |     3709       | 18561507   |    144725     |
|  38   | [cpubench] | metrica_nueva_cpu |     4305       | 18603726   |    124681     |
|  36   | [iobench]  | metrica_nueva_io  |      14        | 18680431   |     71241     |
|  41   | [cpubench] | metrica_nueva_cpu |     4258       | 18631584   |    126071     |
|  40   | [cpubench] | metrica_nueva_cpu |     5614       | 18707092   |     95612     |
|  38   | [cpubench] | metrica_nueva_cpu |     5723       | 18728806   |     93792     |
|  41   | [cpubench] | metrica_nueva_cpu |     7295       | 18757926   |     73589     |
|  40   | [cpubench] | metrica_nueva_cpu |     6855       | 18803054   |     78307     |
|  41   | [cpubench] | metrica_nueva_cpu |     8446       | 18831820   |     63557     |
|  38   | [cpubench] | metrica_nueva_cpu |     6547       | 18822872   |     81987     |
|  40   | [cpubench] | metrica_nueva_cpu |     5878       | 18881610   |     91316     |
|  41   | [cpubench] | metrica_nueva_cpu |     6294       | 18895493   |     85291     |
|  38   | [cpubench] | metrica_nueva_cpu |     5843       | 18905158   |     91871     |
|  40   | [cpubench] | metrica_nueva_cpu |     5696       | 18973229   |     94242     |
|  41   | [cpubench] | metrica_nueva_cpu |     6095       | 18981117   |     88076     |
|  38   | [cpubench] | metrica_nueva_cpu |     6013       | 18997280   |     89271     |
|  40   | [cpubench] | metrica_nueva_cpu |    11947       | 19067733   |     44932     |


    $ cpubench 10 &; iobench 10 &; iobench 10 &; iobench 10 &
|  PID  |   Nombre   |      Métrica      | ops_per_second | start_tick | elapsed_ticks |
|:-----:|:----------:|:-----------------:|:--------------:|:----------:|:-------------:|
|  52   | [iobench]  | metrica_nueva_io  |      22        | 21141215   |     45430     |
|  53   | [iobench]  | metrica_nueva_io  |      20        | 21141152   |     49361     |
|  48   | [cpubench] | metrica_nueva_cpu |     6398       | 21141069   |     83900     |
|  52   | [iobench]  | metrica_nueva_io  |      23        | 21187058   |     43369     |
|  50   | [iobench]  | metrica_nueva_io  |      23        | 21190842   |     43351     |
|  53   | [iobench]  | metrica_nueva_io  |      23        | 21190655   |     44064     |
|  52   | [iobench]  | metrica_nueva_io  |      24        | 21230774   |     41922     |
|  53   | [iobench]  | metrica_nueva_io  |      25        | 21234979   |     39877     |
|  50   | [iobench]  | metrica_nueva_io  |      21        | 21234562   |     46984     |
|  48   | [cpubench] | metrica_nueva_cpu |     7010       | 21225309   |     76573     |
|  52   | [iobench]  | metrica_nueva_io  |      25        | 21273013   |     40784     |
|  53   | [iobench]  | metrica_nueva_io  |      24        | 21275119   |     41895     |
|  50   | [iobench]  | metrica_nueva_io  |      23        | 21282030   |     43252     |
|  52   | [iobench]  | metrica_nueva_io  |      25        | 21314161   |     40695     |
|  53   | [iobench]  | metrica_nueva_io  |      25        | 21317219   |     40427     |
|  50   | [iobench]  | metrica_nueva_io  |      24        | 21325548   |     42511     |
|  48   | [cpubench] | metrica_nueva_cpu |     7253       | 21302017   |     74011     |
|  53   | [iobench]  | metrica_nueva_io  |      29        | 21357951   |     35262     |
|  52   | [iobench]  | metrica_nueva_io  |      24        | 21355192   |     42613     |
|  50   | [iobench]  | metrica_nueva_io  |      20        | 21368326   |     50161     |
|  53   | [iobench]  | metrica_nueva_io  |      22        | 21393477   |     45358     |
|  48   | [cpubench] | metrica_nueva_cpu |     7999       | 21376030   |     67109     |
|  52   | [iobench]  | metrica_nueva_io  |      20        | 21398211   |     49492     |
|  50   | [iobench]  | metrica_nueva_io  |      19        | 21418927   |     52557     |
|  53   | [iobench]  | metrica_nueva_io  |      24        | 21439118   |     41332     |
|  52   | [iobench]  | metrica_nueva_io  |      23        | 21448285   |     43971     |
|  48   | [cpubench] | metrica_nueva_cpu |     7948       | 21443353   |     67537     |
|  52   | [iobench]  | metrica_nueva_io  |      22        | 21492446   |     46507     |
|  53   | [iobench]  | metrica_nueva_io  |      23        | 21521948   |     43541     |
|  50   | [iobench]  | metrica_nueva_io  |      22        | 21521859   |     44789     |
|  52   | [iobench]  | metrica_nueva_io  |      24        | 21539201   |     41231     |
|  48   | [cpubench] | metrica_nueva_cpu |     6457       | 21511128   |     83137     |
|  50   | [iobench]  | metrica_nueva_io  |      22        | 21567070   |     45354     |
|  48   | [cpubench] | metrica_nueva_cpu |    16504       | 21594410   |     32526     |
|  48   | [cpubench] | metrica_nueva_cpu |    11355       | 21626962   |     47274     |
|  48   | [cpubench] | metrica_nueva_cpu |    11055       | 21674390   |     48558     |
|  48   | [cpubench] | metrica_nueva_cpu |    11040       | 21723097   |     48625     |

### Quantum = 10000

    $ iobench 10 &

| PID | Nombre    | Métrica                | ops_per_second | start_ticks | elapsed_ticks |
|-----|-----------|-----------------------|----------------|-------------|----------------|
| 4   | [iobench] | metrica_nueva_io      | 519            | 486620      | 1971           |
| 4   | [iobench] | metrica_nueva_io      | 555            | 488598      | 1845           |
| 4   | [iobench] | metrica_nueva_io      | 503            | 490449      | 2034           |
| 4   | [iobench] | metrica_nueva_io      | 511            | 492490      | 2001           |
| 4   | [iobench] | metrica_nueva_io      | 521            | 494499      | 1963           |
| 4   | [iobench] | metrica_nueva_io      | 542            | 496469      | 1886           |
| 4   | [iobench] | metrica_nueva_io      | 534            | 498363      | 1917           |
| 4   | [iobench] | metrica_nueva_io      | 564            | 500291      | 1813           |
| 4   | [iobench] | metrica_nueva_io      | 547            | 502110      | 1871           |
| 4   | [iobench] | metrica_nueva_io      | 570            | 503987      | 1795           |

    $ iobench 10 &; iobench 10 &; iobench 10 &

| PID | Nombre    | Métrica                | ops_per_second | start_ticks | elapsed_ticks |
|-----|-----------|-----------------------|----------------|-------------|----------------|
| 6   | [iobench] | metrica_nueva_io      | 622            | 5338        | 1645           |
| 8   | [iobench] | metrica_nueva_io      | 573            | 5339        | 1786           |
| 9   | [iobench] | metrica_nueva_io      | 463            | 5341        | 2209           |
| 8   | [iobench] | metrica_nueva_io      | 648            | 7142        | 1578           |
| 6   | [iobench] | metrica_nueva_io      | 555            | 7003        | 1842           |
| 9   | [iobench] | metrica_nueva_io      | 589            | 7559        | 1738           |
| 8   | [iobench] | metrica_nueva_io      | 580            | 8729        | 1765           |
| 6   | [iobench] | metrica_nueva_io      | 603            | 8853        | 1698           |
| 9   | [iobench] | metrica_nueva_io      | 629            | 9306        | 1627           |
| 8   | [iobench] | metrica_nueva_io      | 592            | 10504       | 1728           |
| 6   | [iobench] | metrica_nueva_io      | 493            | 10558       | 2075           |
| 9   | [iobench] | metrica_nueva_io      | 530            | 10944       | 1931           |
| 8   | [iobench] | metrica_nueva_io      | 516            | 12242       | 1981           |
| 6   | [iobench] | metrica_nueva_io      | 515            | 12646       | 1987           |
| 9   | [iobench] | metrica_nueva_io      | 488            | 12884       | 2098           |
| 8   | [iobench] | metrica_nueva_io      | 537            | 14232       | 1905           |
| 6   | [iobench] | metrica_nueva_io      | 540            | 14645       | 1894           |
| 9   | [iobench] | metrica_nueva_io      | 515            | 14993       | 1985           |
| 8   | [iobench] | metrica_nueva_io      | 544            | 16151       | 1879           |
| 6   | [iobench] | metrica_nueva_io      | 590            | 16548       | 1733           |
| 9   | [iobench] | metrica_nueva_io      | 585            | 16990       | 1748           |
| 8   | [iobench] | metrica_nueva_io      | 622            | 18041       | 1644           |
| 6   | [iobench] | metrica_nueva_io      | 578            | 18295       | 1771           |
| 9   | [iobench] | metrica_nueva_io      | 564            | 18747       | 1815           |
| 6   | [iobench] | metrica_nueva_io      | 681            | 20078       | 1503           |
| 8   | [iobench] | metrica_nueva_io      | 486            | 19696       | 2104           |
| 9   | [iobench] | metrica_nueva_io      | 502            | 20572       | 2038           |
| 6   | [iobench] | metrica_nueva_io      | 527            | 21598       | 1940           |
| 8   | [iobench] | metrica_nueva_io      | 583            | 21810       | 1756           |
| 9   | [iobench] | metrica_nueva_io      | 503            | 22623       | 2035           |

    cpubench 10 &;

| PID | Nombre    | Métrica               | ops_per_second | start_ticks | elapsed_ticks |
|-----|-----------|-----------------------|----------------|-------------|----------------|
| 13  | [cpubench] | metrica_nueva_cpu     | 478033         | 80857       | 1123           |
| 13  | [cpubench] | metrica_nueva_cpu     | 486701         | 81988       | 1103           |
| 13  | [cpubench] | metrica_nueva_cpu     | 492054         | 83099       | 1091           |
| 13  | [cpubench] | metrica_nueva_cpu     | 490705         | 84196       | 1094           |
| 13  | [cpubench] | metrica_nueva_cpu     | 488918         | 85296       | 1098           |
| 13  | [cpubench] | metrica_nueva_cpu     | 497066         | 86400       | 1080           |
| 13  | [cpubench] | metrica_nueva_cpu     | 495689         | 87487       | 1083           |
| 13  | [cpubench] | metrica_nueva_cpu     | 493865         | 88576       | 1087           |
| 13  | [cpubench] | metrica_nueva_cpu     | 496606         | 89670       | 1081           |
| 13  | [cpubench] | metrica_nueva_cpu     | 492958         | 90760       | 1089           |

    $ cpubench 10 &; cpubench 10 &; cpubench 10 &

| PID | Nombre    | Métrica               | ops_per_second | start_ticks | elapsed_ticks |
|-----|-----------|-----------------------|----------------|-------------|----------------|
| 7   | [cpubench] | metrica_nueva_cpu     | 174863         | 3197        | 3070           |
| 5   | [cpubench] | metrica_nueva_cpu     | 171676         | 3196        | 3127           |
| 8   | [cpubench] | metrica_nueva_cpu     | 166718         | 3201        | 3220           |
| 7   | [cpubench] | metrica_nueva_cpu     | 170585         | 6285        | 3147           |
| 5   | [cpubench] | metrica_nueva_cpu     | 171074         | 6341        | 3138           |
| 8   | [cpubench] | metrica_nueva_cpu     | 165179         | 6439        | 3250           |
| 7   | [cpubench] | metrica_nueva_cpu     | 171020         | 9447        | 3139           |
| 5   | [cpubench] | metrica_nueva_cpu     | 170531         | 9497        | 3148           |
| 8   | [cpubench] | metrica_nueva_cpu     | 165077         | 9707        | 3252           |
| 7   | [cpubench] | metrica_nueva_cpu     | 170260         | 12604       | 3153           |
| 5   | [cpubench] | metrica_nueva_cpu     | 169454         | 12663       | 3168           |
| 8   | [cpubench] | metrica_nueva_cpu     | 164168         | 12974       | 3270           |
| 7   | [cpubench] | metrica_nueva_cpu     | 170585         | 15775       | 3147           |
| 5   | [cpubench] | metrica_nueva_cpu     | 170422         | 15849       | 3150           |
| 8   | [cpubench] | metrica_nueva_cpu     | 164773         | 16262       | 3258           |
| 7   | [cpubench] | metrica_nueva_cpu     | 170098         | 18943       | 3156           |
| 5   | [cpubench] | metrica_nueva_cpu     | 170748         | 19020       | 3144           |
| 8   | [cpubench] | metrica_nueva_cpu     | 165382         | 19538       | 3246           |
| 7   | [cpubench] | metrica_nueva_cpu     | 168497         | 22114       | 3186           |
| 5   | [cpubench] | metrica_nueva_cpu     | 168655         | 22182       | 3183           |
| 8   | [cpubench] | metrica_nueva_cpu     | 162528         | 22799       | 3303           |
| 7   | [cpubench] | metrica_nueva_cpu     | 169937         | 25318       | 3159           |
| 5   | [cpubench] | metrica_nueva_cpu     | 169937         | 25383       | 3159           |
| 8   | [cpubench] | metrica_nueva_cpu     | 164470         | 26117       | 3264           |
| 7   | [cpubench] | metrica_nueva_cpu     | 169134         | 28492       | 3174           |
| 5   | [cpubench] | metrica_nueva_cpu     | 169294         | 28557       | 3171           |
| 8   | [cpubench] | metrica_nueva_cpu     | 163220         | 29399       | 3289           |
| 7   | [cpubench] | metrica_nueva_cpu     | 168762         | 31681       | 3181           |
| 5   | [cpubench] | metrica_nueva_cpu     | 170098         | 31746       | 3156           |
| 8   | [cpubench] | metrica_nueva_cpu     | 210110         | 32706       | 2555           |

    $ iobench 10 &; cpubench 10 &; cpubench 10 &; cpubench 10 &

| PID | Nombre    | Métrica               | ops_per_second | start_ticks | elapsed_ticks |
|-----|-----------|-----------------------|----------------|-------------|----------------|
| 9   | [cpubench] | metrica_nueva_cpu     | 166718         | 1722        | 3220           |
| 10  | [cpubench] | metrica_nueva_cpu     | 161550         | 1719        | 3323           |
| 9   | [cpubench] | metrica_nueva_cpu     | 165179         | 4963        | 3250           |
| 7   | [cpubench] | metrica_nueva_cpu     | 82386          | 1717        | 6516           |
| 10  | [cpubench] | metrica_nueva_cpu     | 161259         | 5060        | 3329           |
| 9   | [cpubench] | metrica_nueva_cpu     | 164874         | 8231        | 3256           |
| 5   | [iobench]  | metrica_nueva_io      | 103            | 1708        | 9920           |
| 10  | [cpubench] | metrica_nueva_cpu     | 160439         | 8408        | 3346           |
| 7   | [cpubench] | metrica_nueva_cpu     | 87574          | 8267        | 6130           |
| 9   | [cpubench] | metrica_nueva_cpu     | 165128         | 11509       | 3251           |
| 10  | [cpubench] | metrica_nueva_cpu     | 163419         | 11772       | 3285           |
| 9   | [cpubench] | metrica_nueva_cpu     | 164824         | 14778       | 3257           |
| 10  | [cpubench] | metrica_nueva_cpu     | 161210         | 15075       | 3330           |
| 7   | [cpubench] | metrica_nueva_cpu     | 79260          | 14446       | 6773           |
| 9   | [cpubench] | metrica_nueva_cpu     | 160776         | 18056       | 3339           |
| 5   | [iobench]  | metrica_nueva_io      | 102            | 11652       | 9948           |
| 10  | [cpubench] | metrica_nueva_cpu     | 154572         | 18430       | 3473           |
| 9   | [cpubench] | metrica_nueva_cpu     | 161501         | 21421       | 3324           |
| 10  | [cpubench] | metrica_nueva_cpu     | 157752         | 21924       | 3403           |
| 7   | [cpubench] | metrica_nueva_cpu     | 82109          | 21252       | 6538           |
| 9   | [cpubench] | metrica_nueva_cpu     | 162038         | 24766       | 3313           |
| 10  | [cpubench] | metrica_nueva_cpu     | 159486         | 25345       | 3366           |
| 9   | [cpubench] | metrica_nueva_cpu     | 160535         | 28100       | 3344           |
| 5   | [iobench]  | metrica_nueva_io      | 103            | 21624       | 9882           |
| 10  | [cpubench] | metrica_nueva_cpu     | 156739         | 28732       | 3425           |
| 7   | [cpubench] | metrica_nueva_cpu     | 85537          | 27826       | 6276           |
| 9   | [cpubench] | metrica_nueva_cpu     | 166562         | 31470       | 3223           |
| 10  | [cpubench] | metrica_nueva_cpu     | 175206         | 32175       | 3064           |
| 7   | [cpubench] | metrica_nueva_cpu     | 186141         | 34135       | 2884           |
| 5   | [iobench]  | metrica_nueva_io      | 176            | 31530       | 5790           |
| 7   | [cpubench] | metrica_nueva_cpu     | 254181         | 37033       | 2112           |
| 5   | [iobench]  | metrica_nueva_io      | 305            | 37332       | 3355           |
| 7   | [cpubench] | metrica_nueva_cpu     | 255877         | 39157       | 2098           |
| 7   | [cpubench] | metrica_nueva_cpu     | 248303         | 41267       | 2162           |
| 5   | [iobench]  | metrica_nueva_io      | 304            | 40697       | 3362           |
| 7   | [cpubench] | metrica_nueva_cpu     | 255391         | 43443       | 2102           |
| 5   | [iobench]  | metrica_nueva_io      | 412            | 44069       | 2483           |
| 5   | [iobench]  | metrica_nueva_io      | 573            | 46558       | 1786           |
| 5   | [iobench]  | metrica_nueva_io      | 580            | 48350       | 1765           |
| 5   | [iobench]  | metrica_nueva_io      | 586            | 50120       | 1745           |


    $ cpubench 10 &; iobench 10 &; iobench 10 &; iobench 10 &

| PID | Nombre    | Métrica               | ops_per_second | start_ticks | elapsed_ticks |
|-----|-----------|-----------------------|----------------|-------------|---------------|
| 5   | [cpubench] | metrica_nueva_cpu     | 221739         | 1372        | 2421          |
| 7   | [iobench]  | metrica_nueva_io      | 249            | 1382        | 4109          |
| 10  | [iobench]  | metrica_nueva_io      | 240            | 1384        | 4259          |
| 9   | [iobench]  | metrica_nueva_io      | 224            | 1386        | 4560          |
| 5   | [cpubench] | metrica_nueva_cpu     | 199565         | 3807        | 2690          |
| 7   | [iobench]  | metrica_nueva_io      | 311            | 5508        | 3292          |
| 5   | [cpubench] | metrica_nueva_cpu     | 204351         | 6510        | 2627          |
| 9   | [iobench]  | metrica_nueva_io      | 290            | 5958        | 3528          |
| 10  | [iobench]  | metrica_nueva_io      | 215            | 5672        | 4759          |
| 5   | [cpubench] | metrica_nueva_cpu     | 225464         | 9156        | 2381          |
| 7   | [iobench]  | metrica_nueva_io      | 276            | 8815        | 3710          |
| 9   | [iobench]  | metrica_nueva_io      | 239            | 9505        | 4269          |
| 5   | [cpubench] | metrica_nueva_cpu     | 227182         | 11549       | 2363          |
| 10  | [iobench]  | metrica_nueva_io      | 214            | 10451       | 4769          |
| 7   | [iobench]  | metrica_nueva_io      | 327            | 12537       | 3130          |
| 5   | [cpubench] | metrica_nueva_cpu     | 227086         | 13923       | 2364          |
| 9   | [iobench]  | metrica_nueva_io      | 252            | 13792       | 4050          |
| 5   | [cpubench] | metrica_nueva_cpu     | 233405         | 16300       | 2300          |
| 7   | [iobench]  | metrica_nueva_io      | 331            | 15679       | 3091          |
| 10  | [iobench]  | metrica_nueva_io      | 218            | 15237       | 4684          |
| 5   | [cpubench] | metrica_nueva_cpu     | 238380         | 18622       | 2252          |
| 9   | [iobench]  | metrica_nueva_io      | 258            | 17856       | 3955          |
| 7   | [iobench]  | metrica_nueva_io      | 304            | 18781       | 3358          |
| 5   | [cpubench] | metrica_nueva_cpu     | 227374         | 20885       | 2361          |
| 10  | [iobench]  | metrica_nueva_io      | 221            | 19937       | 4629          |
| 7   | [iobench]  | metrica_nueva_io      | 302            | 22151       | 3389          |
| 5   | [cpubench] | metrica_nueva_cpu     | 234015         | 23263       | 2294          |
| 9   | [iobench]  | metrica_nueva_io      | 243            | 21827       | 4205          |
| 10  | [iobench]  | metrica_nueva_io      | 423            | 24589       | 2416          |
| 7   | [iobench]  | metrica_nueva_io      | 562            | 25550       | 1819          |
| 9   | [iobench]  | metrica_nueva_io      | 658            | 26042       | 1554          |
| 10  | [iobench]  | metrica_nueva_io      | 629            | 27016       | 1627          |
| 9   | [iobench]  | metrica_nueva_io      | 702            | 27606       | 1458          |
| 7   | [iobench]  | metrica_nueva_io      | 502            | 27385       | 2038          |
| 10  | [iobench]  | metrica_nueva_io      | 638            | 28656       | 1605          |
| 9   | [iobench]  | metrica_nueva_io      | 613            | 29074       | 1668          |
| 7   | [iobench]  | metrica_nueva_io      | 643            | 29434       | 1592          |
| 10  | [iobench]  | metrica_nueva_io      | 562            | 30273       | 1820          |
| 9   | [iobench]  | metrica_nueva_io      | 555            | 30751       | 1842          |
| 10  | [iobench]  | metrica_nueva_io      | 546            | 32104       | 1873          |



## Cuarta Parte
# Informe de Métricas de Experimento

*  ¿Se puede producir starvation en el nuevo planificador? 

        El planificador tal como esta implementado puede producir casos de starvation. Un programa que esta en starvation es un programa que no tiene tiempo de cpu, osea casi no puede ejecutarse. En este caso porque el programa requiere mucho tiempo de ejecución y no devuelve la cpu en el tiempo de quantum, que termina implicando que baje la prioridad contantemente y los programas que no requieran tanto tiempo de cpu tengas mas prioridad, dejando sin ejecutarse al programa. En el mlfq tal como esta implementado no hay ningun recurso que impida que esto suceda.
        Una solución a este problma podría ser un reset de prioridades después de un X tiempo o de una Y cantidad de ejecuciones de programas, dando así de nuevo máxima prioridad a todos los programas incluido el que estaba en starvation sin poder subir de prioridad.



        
    iobench 10 &

| PID | Nombre   | Métrica          | total_iops | start_ticks | elapsed_ticks |
|:-----:|:----------:|:------------------:|:------------:|:-------------:|:---------------:|
| 4   | [iobench] | metric_name_io | 1024       | 111         | 82           |
| 4   | [iobench] | metric_name_io | 1024       | 194         | 78           |
| 4   | [iobench] | metric_name_io | 1024       | 273         | 79           |
| 4   | [iobench] | metric_name_io | 1024       | 352         | 78           |
| 4   | [iobench] | metric_name_io | 1024       | 431         | 79           |
| 4   | [iobench] | metric_name_io | 1024       | 510         | 79           |
| 4   | [iobench] | metric_name_io | 1024       | 589         | 79           |
| 4   | [iobench] | metric_name_io | 1024       | 668         | 80           |
| 4   | [iobench] | metric_name_io | 1024       | 748         | 81           |
| 4   | [iobench] | metric_name_io | 1024       | 830         | 78           |

    iobench 10 &; iobench 10 &; iobench 10 &

| PID | Nombre   | Métrica          | total_iops | start_ticks | elapsed_ticks |
|:-----:|:----------:|:------------------:|:------------:|:-------------:|:---------------:|
| 12  | [iobench] | metric_name_io | 1024       | 1630        | 47           |
| 8   | [iobench] | metric_name_io | 1024       | 1628        | 92           |
| 10  | [iobench] | metric_name_io | 1024       | 1628        | 93           |
| 12  | [iobench] | metric_name_io | 1024       | 1677        | 66           |
| 8   | [iobench] | metric_name_io | 1024       | 1721        | 57           |
| 10  | [iobench] | metric_name_io | 1024       | 1721        | 74           |
| 12  | [iobench] | metric_name_io | 1024       | 1744        | 70           |
| 12  | [iobench] | metric_name_io | 1024       | 1814        | 37           |
| 10  | [iobench] | metric_name_io | 1024       | 1795        | 65           |
| 8   | [iobench] | metric_name_io | 1024       | 1779        | 115          |
| ... | ...      | ...             | ...        | ...         | ...          |

    cpubench 10 &

| PID | Nombre   | Métrica          | total_ops  | start_ticks | elapsed_ticks |
|:-----:|:----------:|:------------------:|:------------:|:-------------:|:---------------:|
| 16  | [cpubench] | metric_name_cpu | 536832     | 3857        | 16           |
| 16  | [cpubench] | metric_name_cpu | 536832     | 3873        | 15           |
| 16  | [cpubench] | metric_name_cpu | 536832     | 3889        | 15           |
| 16  | [cpubench] | metric_name_cpu | 536832     | 3904        | 16           |
| 16  | [cpubench] | metric_name_cpu | 536832     | 3920        | 16           |
| 16  | [cpubench] | metric_name_cpu | 536832     | 3936        | 16           |
| 16  | [cpubench] | metric_name_cpu | 536832     | 3952        | 15           |
| 16  | [cpubench] | metric_name_cpu | 536832     | 3968        | 16           |
| 16  | [cpubench] | metric_name_cpu | 536832     | 3984        | 16           |
| 16  | [cpubench] | metric_name_cpu | 536832     | 4001        | 15           |


    cpubench 10 &; cpubench 10 &; cpubench 10 &
| PID | Nombre   | Métrica          | total_iops      | start_ticks | elapsed_ticks |
|:-----:|:----------------:|:-------------------:|:-------------:|:-----------:|:-------:|
| 20  | [cpubench]     | metric_name_cpu   | 536832      | 4361      | 46    |
| 22  | [cpubench]     | metric_name_cpu   | 536832      | 4363      | 45    |
| 23  | [cpubench]     | metric_name_cpu   | 536832      | 4364      | 45    |
| 20  | [cpubench]     | metric_name_cpu   | 536832      | 4407      | 48    |
| 22  | [cpubench]     | metric_name_cpu   | 536832      | 4408      | 48    |
| 23  | [cpubench]     | metric_name_cpu   | 536832      | 4412      | 45    |
| 20  | [cpubench]     | metric_name_cpu   | 536832      | 4455      | 45    |
| 22  | [cpubench]     | metric_name_cpu   | 536832      | 4456      | 45    |
| 23  | [cpubench]     | metric_name_cpu   | 536832      | 4457      | 45    |
| 20  | [cpubench]     | metric_name_cpu   | 536832      | 4500      | 48    |
| 22  | [cpubench]     | metric_name_cpu   | 536832      | 4501      | 48    |
| 23  | [cpubench]     | metric_name_cpu   | 536832      | 4505      | 45    |
| 20  | [cpubench]     | metric_name_cpu   | 536832      | 4548      | 25    |
| 22  | [cpubench]     | metric_name_cpu   | 536832      | 4549      | 45    |
| 23  | [cpubench]     | metric_name_cpu   | 536832      | 4550      | 48    |
| 20  | [cpubench]     | metric_name_cpu   | 536832      | 4596      | 45    |
| 22  | [cpubench]     | metric_name_cpu   | 536832      | 4594      | 48    |
| 23  | [cpubench]     | metric_name_cpu   | 536832      | 4598      | 45    |
| 20  | [cpubench]     | metric_name_cpu   | 536832      | 4641      | 45    |
| 22  | [cpubench]     | metric_name_cpu   | 536832      | 4642      | 45    |
| 23  | [cpubench]     | metric_name_cpu   | 536832      | 4646      | 45    |
| 20  | [cpubench]     | metric_name_cpu   | 536832      | 4689      | 45    |
| 22  | [cpubench]     | metric_name_cpu   | 536832      | 4690      | 45    |
| 23  | [cpubench]     | metric_name_cpu   | 536832      | 4691      | 45    |
| 20  | [cpubench]     | metric_name_cpu   | 536832      | 4734      | 45    |
| 22  | [cpubench]     | metric_name_cpu   | 536832      | 4735      | 45    |
| 23  | [cpubench]     | metric_name_cpu   | 536832      | 4739      | 45    |
| 20  | [cpubench]     | metric_name_cpu   | 536832      | 4782      | 45    |
| 22  | [cpubench]     | metric_name_cpu   | 536832      | 4783      | 46    |
| 23  | [cpubench]     | metric_name_cpu   | 536832      | 4784      | 45    |

    iobench 10 &; cpubench 10 &; cpubench 10 &; cpubench 10 &
| PID | Nombre   | Métrica                 |total.iops|start.ticks| elapsed_ticks |
|:-----:|:------------:|:-----------------------:|:--------:|:--------:|:-------------:|
| 31  | cpubench   | metric_name_cpu       | 536832 | 11444  | 45          |
| 32  | cpubench   | metric_name_cpu       | 536832 | 11445  | 45          |
| 29  | cpubench   | metric_name_cpu       | 536832 | 11442  | 49          |
| 31  | cpubench   | metric_name_cpu       | 536832 | 11489  | 48          |
| 32  | cpubench   | metric_name_cpu       | 536832 | 11493  | 45          |
| 29  | cpubench   | metric_name_cpu       | 536832 | 11491  | 48          |
| 31  | cpubench   | metric_name_cpu       | 5336832| 11537  | 45          |
| 2   | cpubench   | metric_name_cpu       | 536832 | 11538  | 45          |
| 29  | cpubench   | metric_name_cpu       | 536832 | 11539  | 48          |
| 31  | cpubench   | metric_name_cpu       | 536832 | 11585  | 45          |
| 32  | cpubench   | metric_name_cpu       | 536832 | 11586  | 45          |
| 29  | cpubench   | metric_name_cpu       | 536832 | 11587  | 48          |
| 31  | cpubench   | metric_name_cpu       | 536832 | 11630  | 45          |
| 32  | cpubench   | metric_name_cpu       | 536832 | 11631  | 48          |
| 29  | cpubench   | metric_name_cpu       | 536832 | 11635  | 48          |
| 31  | cpubench   | metric_name_cpu       | 536832 | 11678  | 45          |
| 32  | cpubench   | metric_name_cpu       | 536832 | 11679  | 45          |
| 29  | cpubench   | metric_name_cpu       | 536832 | 11683  | 45          |
| 31  | cpubench   | metric_name_cpu       | 536832 | 11723  | 48          |
| 32  | cpubench   | metric_name_cpu       | 536832 | 11727  | 45          |
| 29  | cpubench   | metric_name_cpu       | 536832 | 11731  | 45          |
| 31  | cpubench   | metric_name_cpu       | 536832 | 11771  | 45          |
| 32  | cpubench   | metric_name_cpu       | 536832 | 11772  | 45          |
| 29  | cpubench   | metric_name_cpu       | 536832 | 11779  | 45          |
| 31  | cpubench   | metric_name_cpu       | 536832 | 11816  | 48          |
| 32  | cpubench   | metric_name_cpu       | 536832 | 11820  | 45          |
| 29  | cpubench   | metric_name_cpu       | 536832 | 11827  | 45          |
| 31  | cpubench   | metric_name_cpu       | 536832 | 11864  | 45          |
| 32  | cpubench   | metric_name_cpu       | 536832 | 11865  | 47          |
| 29  | cpubench   | metric_name_cpu       | 536832 | 11872  | 43          |
| 27  | iobench    | metric_name_io        | 1024   | 11458  | 535         |
| 27  | iobench    | metric_name_io        | 1024   | 11993  | 79          |
| 27  | iobench    | metric_name_io        | 1024   | 12072  | 79          |
| 27  | iobench    | metric_name_io        | 1024   | 12151  | 85          |
| 27  | iobench    | metric_name_io        | 1024   | 12236  | 90          |
| 27  | iobench    | metric_name_io        | 1024   | 12326  | 89          |
| 27  | iobench    | metric_name_io        | 1024   | 12415  | 93          |
| 27  | iobench    | metric_name_io        | 1024   | 12508  | 89          |
| 27  | iobench    | metric_name_io        | 1024   | 12598  | 87          |
| 27  | iobench    | metric_name_io        | 1024   | 12686  | 86          |

    cpubench 10 &; iobench 10 &; iobench 10 &; iobench 10 &
| PID | Nombre   | Métrica            |total.iops|start.ticks| elapsed_ticks |
|:-----:|:------------:|:------------------:|:------------:|:-----------:|:-------:|
| 37  | cpubench   | metric_name_cpu  | 536832     | 15168     | 18    |
| 37  | cpubench   | metric_name_cpu  | 536832     | 15187     | 15    |
| 37  | cpubench   | metric_name_cpu  | 536832     | 15203     | 15    |
| 37  | cpubench   | metric_name_cpu  | 536832     | 15219     | 15    |
| 37  | cpubench   | metric_name_cpu  | 536832     | 15235     | 15    |
| 37  | cpubench   | metric_name_cpu  | 536832     | 15251     | 15    |
| 37  | cpubench   | metric_name_cpu  | 536832     | 15267     | 20    |
| 37  | cpubench   | metric_name_cpu  | 536832     | 15287     | 16    |
| 37  | cpubench   | metric_name_cpu  | 536832     | 15303     | 19    |
| 37  | cpubench   | metric_name_cpu  | 536832     | 15322     | 16    |
| 41  | iobench    | metric_name_io   | 1024       | 15168     | 222   |
| 39  | iobench    | metric_name_io   | 1024       | 15168     | 246   |
| 42  | iobench    | metric_name_io   | 1024       | 15310     | 120   |
| 41  | iobench    | metric_name_io   | 1024       | 15390     | 72    |
| 39  | iobench    | metric_name_io   | 1024       | 15415     | 67    |
| 42  | iobench    | metric_name_io   | 1024       | 15431     | 75    |
| 41  | iobench    | metric_name_io   | 1024       | 15462     | 72    |
| 39  | iobench    | metric_name_io   | 1024       | 15483     | 71    |
| 42  | iobench    | metric_name_io   | 1024       | 15506     | 84    |
| 41  | iobench    | metric_name_io   | 1024       | 15534     | 75    |
| 39  | iobench    | metric_name_io   | 1024       | 15554     | 64    |
| 42  | iobench    | metric_name_io   | 1024       | 15590     | 58    |
| 41  | iobench    | metric_name_io   | 1024       | 15609     | 72    |
| 39  | iobench    | metric_name_io   | 1024       | 15619     | 75    |
| 42  | iobench    | metric_name_io   | 1024       | 15649     | 95    |
| 39  | iobench    | metric_name_io   | 1024       | 15695     | 57    |
| 41  | iobench    | metric_name_io   | 1024       | 15681     | 80    |
| 39  | iobench    | metric_name_io   | 1024       | 15753     | 64    |
| 41  | iobench    | metric_name_io   | 1024       | 15761     | 75    |
| 42  | iobench    | metric_name_io   | 1024       | 15745     | 92    |
| 39  | iobench    | metric_name_io   | 1024       | 15817     | 54    |
| 41  | iobench    | metric_name_io   | 1024       | 15837     | 70    |
| 42  | iobench    | metric_name_io   | 1024       | 15837     | 70    |
| 41  | iobench    | metric_name_io   | 1024       | 15907     | 59    |
| 42  | iobench    | metric_name_io   | 1024       | 15907     | 59    |
| 39  | iobench    | metric_name_io   | 1024       | 15871     | 107   |
| 42  | iobench    | metric_name_io   | 1024       | 15966     | 61    |
| 41  | iobench    | metric_name_io   | 1024       | 15966     | 78    |
| 39  | iobench    | metric_name_io   | 1024       | 15978     | 75    |
| 42  | iobench    | metric_name_io   | 1024       | 16027     | 73    |

